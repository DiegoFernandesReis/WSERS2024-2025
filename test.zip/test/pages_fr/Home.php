<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="../style.css">
    <img src="../images/nintendo_banner.webp" id="image">
    <title>Homepage</title>
    <meta charset="utf-8">
  </head>
  <body>
    <?php
    include_once("Commoncode.php");
    NavigationBar("home");
    ?>
 
    <h1>Nintendo switch boutique enligne</h1>

    <h2>Produits en vente</h2>

    <dl>
      <dd><a href="Controller.php">Manette pro</a></dd>
      <dt><img src="../images/controller.jpeg"></dt>
      <dd><a href="Nintendo switch.php">Nintendo switch</a></dd>
      <dt><img src="../images/Nintendo switch.jpg"></dt>
      <dd><a href="Accesories.php">Accesoires</a></dd>
      <dt><img src="../images/accessories.jpeg" width="400 px"></dt>
    </dl>
   <style>
        